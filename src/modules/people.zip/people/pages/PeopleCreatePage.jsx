import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";

import { addPerson } from "../store/peopleThunks";
import PersonForm from "../components/PersonForm";

export default function PeopleCreatePage() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  async function handleSubmit(data) {
    try {
      await dispatch(addPerson(data)).unwrap();
      navigate("/people");
    } catch (err) {
      console.error("Erro ao salvar pessoa:", err);
      alert("Erro ao salvar pessoa");
    }
  }

  return <PersonForm onSubmit={handleSubmit} />;
}

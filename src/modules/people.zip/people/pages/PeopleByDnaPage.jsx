export default function PeopleByDnaPage() {
  return <div>Pessoas do meu DNA</div>;
}

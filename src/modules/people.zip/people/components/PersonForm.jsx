import { useState } from "react";

import PageHeader from "@/components/ui/PageHeader";
import Input from "@/components/ui/Input";
import Button from "@/components/ui/Button";

export default function PersonForm({ onSubmit }) {
  const [form, setForm] = useState({
    nome: "",
    telefone: "",
    enderecoTexto: "",
    cep: "",
    numero: "",
    cidade: "",
    estado: "",
    tipo: "visitante",
    observacao: "",
  });

  function handleChange(e) {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  }

  function handleSubmit(e) {
    e.preventDefault();

    // validação mínima real
    if (
      !form.nome ||
      !form.cep ||
      !form.cidade ||
      !form.estado
    ) {
      alert(
        "Preencha nome, CEP, cidade e estado para salvar."
      );
      return;
    }

    onSubmit({
      nome: form.nome,
      telefone: form.telefone,
      tipo: form.tipo,
      observacao: form.observacao,

      endereco: {
        texto: form.enderecoTexto,
        cep: form.cep,
        numero: form.numero,
        cidade: form.cidade,
        estado: form.estado,
      },
    });
  }

  return (
    <div className="flex flex-col gap-6 pb-6">
      <PageHeader
        title="Cadastrar visitante"
        subtitle="Essas informações nos ajudam a direcionar a pessoa ao DNA mais próximo."
      />

      <form
        onSubmit={handleSubmit}
        className="w-full max-w-xl flex flex-col gap-4"
      >
        <Input
          label="Nome"
          name="nome"
          value={form.nome}
          onChange={handleChange}
          required
        />

        <Input
          label="Telefone"
          name="telefone"
          value={form.telefone}
          onChange={handleChange}
        />

        <Input
          label="Rua / Descrição"
          name="enderecoTexto"
          placeholder="Rua, bairro"
          value={form.enderecoTexto}
          onChange={handleChange}
        />

        <Input
          label="CEP"
          name="cep"
          placeholder="00000-000"
          value={form.cep}
          onChange={handleChange}
          required
        />

        <Input
          label="Número"
          name="numero"
          value={form.numero}
          onChange={handleChange}
        />

        <Input
          label="Cidade"
          name="cidade"
          value={form.cidade}
          onChange={handleChange}
          required
        />

        <Input
          label="Estado"
          name="estado"
          value={form.estado}
          onChange={handleChange}
          required
        />

        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">
            Como essa pessoa se identifica hoje?
          </label>
          <select
            name="tipo"
            value={form.tipo}
            onChange={handleChange}
            className="
              h-11
              rounded-xl
              border
              border-base-300
              bg-base-100
              px-3
              text-sm
              focus:outline-none
              focus:ring-2
              focus:ring-primary/40
            "
          >
            <option value="visitante">Visitante</option>
            <option value="novo_convertido">
              Novo convertido
            </option>
            <option value="membro">Membro</option>
          </select>
        </div>

        <textarea
          name="observacao"
          value={form.observacao}
          onChange={handleChange}
          rows={3}
          placeholder="Observação pastoral ou administrativa"
          className="
            rounded-xl
            border
            border-base-300
            bg-base-100
            px-3
            py-2
            text-sm
            resize-none
            focus:outline-none
            focus:ring-2
            focus:ring-primary/40
          "
        />

        <div className="flex justify-end pt-2">
          <Button type="submit">
            Salvar visitante
          </Button>
        </div>
      </form>
    </div>
  );
}

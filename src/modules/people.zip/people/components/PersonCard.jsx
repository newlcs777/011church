import { useState, useEffect } from "react";
import PersonStatusBadge from "./PersonStatusBadge";
import Button from "@/components/ui/Button";
import Input from "@/components/ui/Input";
import { findNearestDna } from "../services/findNearestDna";

export default function PersonCard({ person, onUpdate, onDelete }) {
  const [editing, setEditing] = useState(false);
  const [nearestDna, setNearestDna] = useState(null);

  const [form, setForm] = useState({
    nome: person.nome,
    telefone: person.telefone || "",
    observacao: person.observacao || "",
    tipo: person.tipo,
  });

  const [enderecoForm, setEnderecoForm] = useState({
    rua: person.endereco?.rua || "",
    numero: person.endereco?.numero || "",
    bairro: person.endereco?.bairro || "",
    cep: person.endereco?.cep || "",
    cidade: person.endereco?.cidade || "",
    estado: person.endereco?.estado || "",
  });

  /* =======================
     DNA MAIS PRÓXIMO
  ======================= */
  useEffect(() => {
    async function loadNearestDna() {
      if (!person.location?.lat || !person.location?.lng) {
        setNearestDna(null);
        return;
      }

      const dna = await findNearestDna(person.location);
      setNearestDna(dna);
    }

    loadNearestDna();
  }, [person.location]);

  function handleChange(e) {
    setForm((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  }

  function handleEnderecoChange(e) {
    setEnderecoForm((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  }

  function handleSave() {
    onUpdate({
      id: person.id,
      data: {
        nome: form.nome,
        telefone: form.telefone,
        observacao: form.observacao,
        tipo: form.tipo,
        endereco: {
          rua: enderecoForm.rua,
          numero: enderecoForm.numero,
          bairro: enderecoForm.bairro,
          cep: enderecoForm.cep,
          cidade: enderecoForm.cidade,
          estado: enderecoForm.estado,
        },
      },
    });

    setEditing(false);
  }

  function handleCancel() {
    setForm({
      nome: person.nome,
      telefone: person.telefone || "",
      observacao: person.observacao || "",
      tipo: person.tipo,
    });

    setEnderecoForm({
      rua: person.endereco?.rua || "",
      numero: person.endereco?.numero || "",
      bairro: person.endereco?.bairro || "",
      cep: person.endereco?.cep || "",
      cidade: person.endereco?.cidade || "",
      estado: person.endereco?.estado || "",
    });

    setEditing(false);
  }

  return (
    <div className="flex flex-col gap-2 rounded-xl border border-base-300 bg-base-100 px-4 py-3">
      {/* HEADER */}
      <div className="flex items-center justify-between">
        {!editing ? (
          <strong className="text-sm font-medium">
            {person.nome}
          </strong>
        ) : (
          <Input name="nome" value={form.nome} onChange={handleChange} />
        )}

        {!editing && <PersonStatusBadge status={person.tipo} />}
      </div>

      {/* ENDEREÇO */}
      {!editing && person.endereco && (
        <span className="text-xs text-base-content/60">
          📍 {person.endereco.rua}, {person.endereco.numero} –{" "}
          {person.endereco.bairro}
          <br />
          {person.endereco.cidade}/{person.endereco.estado} – CEP{" "}
          {person.endereco.cep}
        </span>
      )}

      {/* DNA MAIS PRÓXIMO */}
      {!editing && nearestDna && (
        <div className="text-xs text-primary mt-1">
          🧬 <strong>{nearestDna.nome}</strong>{" "}
          {typeof nearestDna.distance === "number" && (
            <span className="text-base-content/60">
              ({nearestDna.distance.toFixed(1)} km)
            </span>
          )}
          <br />
          👤 Líder: {nearestDna.liderNome || "Não informado"}
          {nearestDna.whatsapp && (
            <>
              <br />
              📞 {nearestDna.whatsapp}
            </>
          )}
        </div>
      )}

      {/* FORM ENDEREÇO */}
      {editing && (
        <div className="grid grid-cols-2 gap-2">
          <Input name="rua" placeholder="Rua" value={enderecoForm.rua} onChange={handleEnderecoChange} />
          <Input name="numero" placeholder="Número" value={enderecoForm.numero} onChange={handleEnderecoChange} />
          <Input name="bairro" placeholder="Bairro" value={enderecoForm.bairro} onChange={handleEnderecoChange} />
          <Input name="cep" placeholder="CEP" value={enderecoForm.cep} onChange={handleEnderecoChange} />
          <Input name="cidade" placeholder="Cidade" value={enderecoForm.cidade} onChange={handleEnderecoChange} />
          <Input name="estado" placeholder="UF" value={enderecoForm.estado} onChange={handleEnderecoChange} />
        </div>
      )}

      {/* TELEFONE */}
      {!editing && person.telefone && (
        <span className="text-xs text-base-content/70">
          📞 {person.telefone}
        </span>
      )}

      {editing && (
        <Input
          name="telefone"
          placeholder="Telefone"
          value={form.telefone}
          onChange={handleChange}
        />
      )}

      {/* STATUS */}
      {editing && (
        <select
          name="tipo"
          value={form.tipo}
          onChange={handleChange}
          className="h-10 rounded-xl border border-base-300 bg-base-100 px-3 text-sm"
        >
          <option value="visitante">Visitante</option>
          <option value="novo_convertido">Novo convertido</option>
          <option value="membro">Membro</option>
        </select>
      )}

      {/* OBSERVAÇÃO */}
      {!editing && person.observacao && (
        <p className="text-xs text-base-content/60">
          {person.observacao}
        </p>
      )}

      {editing && (
        <textarea
          name="observacao"
          value={form.observacao}
          onChange={handleChange}
          rows={2}
          placeholder="Observação"
          className="rounded-xl border border-base-300 bg-base-100 px-3 py-2 text-sm"
        />
      )}

      {/* ACTIONS */}
      <div className="flex justify-end gap-2 pt-2">
        {!editing ? (
          <>
            <Button size="sm" variant="ghost" onClick={() => setEditing(true)}>
              Editar
            </Button>
            <Button size="sm" variant="ghost" onClick={() => onDelete(person.id)}>
              Excluir
            </Button>
          </>
        ) : (
          <>
            <Button size="sm" onClick={handleSave}>
              Salvar
            </Button>
            <Button size="sm" variant="ghost" onClick={handleCancel}>
              Cancelar
            </Button>
          </>
        )}
      </div>
    </div>
  );
}

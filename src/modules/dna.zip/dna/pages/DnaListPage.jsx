import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import PageHeader from "@/components/ui/PageHeader";
import Button from "@/components/ui/Button";

import useAuth from "@/modules/auth/hooks/useAuth";
import useDna from "../hooks/useDna";
import useDnaSearch from "../hooks/useDnaSearch";
import { canCreateDna } from "../utils/dnaPermissions";

import DnaCard from "../components/DnaCard";
import DnaSearch from "../components/DnaSearch";

export default function DnaPage() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const { getAll } = useDna();
  const { searchByAddress, searchNearby } = useDnaSearch();

  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [searched, setSearched] = useState(false);
  const [dnas, setDnas] = useState([]);

  const canCreate = canCreateDna(user?.role);

  /* ===============================
     LOAD INICIAL
  ============================== */
  useEffect(() => {
    let mounted = true;

    async function load() {
      try {
        const data = await getAll();
        if (mounted && Array.isArray(data)) {
          setDnas(data);
        }
      } finally {
        if (mounted) setLoading(false);
      }
    }

    load();
    return () => (mounted = false);
  }, [getAll]);

  /* ===============================
     🔎 BUSCA POR ENDEREÇO
  ============================== */
  async function handleSearch(address) {
    if (!address || !address.trim()) return;

    setSearching(true);
    setSearched(true);

    try {
      const result = await searchByAddress(address);

      // ✅ se achou, atualiza
      if (Array.isArray(result) && result.length > 0) {
        setDnas(result);
      }
      // ❌ se não achou, NÃO apaga a lista atual
    } finally {
      setSearching(false);
    }
  }

  /* ===============================
     📍 BUSCA POR PROXIMIDADE (GPS)
  ============================== */
  async function handleSearchNearby() {
    setSearching(true);
    setSearched(true);

    try {
      const result = await searchNearby();

      // 🔒 searchNearby SEMPRE deve devolver array
      if (Array.isArray(result)) {
        setDnas(result);
      }
    } finally {
      setSearching(false);
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="DNA"
        subtitle="Encontre um grupo DNA perto de você"
        right={
          canCreate && (
            <Button onClick={() => navigate("/dna/novo")}>
              Criar DNA
            </Button>
          )
        }
      />

      {/* 🔎 Busca por endereço */}
      <DnaSearch onResult={handleSearch} />

      {/* 📍 Busca por proximidade */}
      <Button variant="outline" onClick={handleSearchNearby}>
        📍 Encontrar DNAs perto de mim
      </Button>

      {(loading || searching) && (
        <p className="text-sm text-base-content/60">
          {searching
            ? "Buscando DNAs próximos..."
            : "Carregando DNAs..."}
        </p>
      )}

      {searched && !searching && dnas.length === 0 && (
        <p className="text-sm text-base-content/60">
          Nenhum DNA encontrado.
        </p>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {dnas.map((dna) => (
          <DnaCard
            key={dna.id}
            dna={dna}
            canEdit={
              user?.role === "admin" ||
              user?.role === "pastor" ||
              (user?.role === "lider" &&
                dna.liderId === user?.id)
            }
            onEdit={() => navigate(`/dna/${dna.id}`)}
          />
        ))}
      </div>
    </div>
  );
}

import { geocodeAddress } from "../services/geoService";
import { getDistanceKm } from "../utils/distance";
import { getDnas } from "../services/dnaService";

/* ===============================
   LOCALIZAÇÃO DO USUÁRIO (SAFE)
================================ */
function getUserLocationSafe(timeout = 8000) {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      resolve(null);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        resolve({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        });
      },
      () => {
        resolve(null); // 🔒 NUNCA rejeita
      },
      { timeout }
    );
  });
}

export default function useDnaSearch() {
  /* ===============================
     🔎 BUSCA POR ENDEREÇO
  ============================== */
  async function searchByAddress(address) {
    if (!address) return [];

    const userLocation = await geocodeAddress(address);
    if (!userLocation) return [];

    const dnas = await getDnas();

    return dnas
      .filter((dna) => dna.location)
      .map((dna) => ({
        ...dna,
        distance: getDistanceKm(userLocation, dna.location),
      }))
      .sort((a, b) => a.distance - b.distance);
  }

  /* ===============================
     📍 BUSCA POR GPS (CORRIGIDA)
  ============================== */
  async function searchNearby() {
    const userLocation = await getUserLocationSafe();

    // 🔒 GPS falhou → retorna TODOS os DNAs
    if (!userLocation) {
      return await getDnas();
    }

    const dnas = await getDnas();

    return dnas
      .filter((dna) => dna.location)
      .map((dna) => ({
        ...dna,
        distance: getDistanceKm(userLocation, dna.location),
      }))
      .sort((a, b) => a.distance - b.distance);
  }

  return {
    searchByAddress,
    searchNearby,
  };
}

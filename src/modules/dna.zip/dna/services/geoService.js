// modules/dna/services/geoService.js

export async function geocodeAddress(address) {
  if (!address || address.length < 3) return null;

  const url =
    "https://nominatim.openstreetmap.org/search?" +
    new URLSearchParams({
      q: address,
      format: "json",
      limit: 1,
      addressdetails: 0,
    });

  try {
    const res = await fetch(url);
    if (!res.ok) return null;

    const data = await res.json();
    if (!data || data.length === 0) return null;

    return {
      lat: Number(data[0].lat),
      lng: Number(data[0].lon),
    };
  } catch (err) {
    console.error("Erro no geocode:", err);
    return null;
  }
}

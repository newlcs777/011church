import React from "react";

import Button from "@/components/ui/Button";
import Input from "@/components/ui/Input";

/* ===============================
   VIA CEP
================================ */
async function getAddressByCep(cep) {
  const cleanCep = (cep || "").replace(/\D/g, "");

  if (cleanCep.length !== 8) return null;

  const res = await fetch(
    `https://viacep.com.br/ws/${cleanCep}/json/`
  );
  const data = await res.json();

  if (data.erro) return null;

  return data;
}

/* ===============================
   GEOCODE (PHOTON)
   ✔ tenta gerar lat/lng
   ❌ pode falhar (CORS / 403)
================================ */
async function geocodeAddressOptional(address) {
  try {
    const url =
      "https://photon.komoot.io/api/?" +
      new URLSearchParams({
        q: address,
        limit: 1,
        lang: "pt",
      });

    const res = await fetch(url);
    if (!res.ok) return null;

    const data = await res.json();
    if (!data.features?.length) return null;

    const [lng, lat] =
      data.features[0].geometry.coordinates;

    return {
      lat: Number(lat),
      lng: Number(lng),
    };
  } catch {
    return null;
  }
}

export default function DnaForm({
  initialData,
  onSubmit,
  onCancel,
  isSubmitting = false,
}) {
  const [form, setForm] = React.useState({
    nome: "",
    dia: "",
    horario: "",
    liderNome: "",
    whatsapp: "",

    cep: "",
    endereco: "",
    numero: "",
    complemento: "",
    referencia: "",

    bairro: "",
    cidade: "",
    estado: "",

    location: null,

    ...(initialData || {}),
  });

  const [loadingCep, setLoadingCep] =
    React.useState(false);

  function handleChange(e) {
    const field = e.target.name.replace("dna_", "");
    const value = e.target.value;

    setForm((prev) => ({
      ...prev,
      [field]: value,
    }));
  }

  async function handleBuscarCep() {
    if (!form.cep) {
      alert("Informe o CEP");
      return;
    }

    setLoadingCep(true);

    try {
      const data = await getAddressByCep(form.cep);

      if (!data) {
        alert("CEP não encontrado");
        return;
      }

      setForm((prev) => ({
        ...prev,
        endereco: data.logradouro || "",
        bairro: data.bairro || "",
        cidade: data.localidade || "",
        estado: data.uf || "",
      }));
    } finally {
      setLoadingCep(false);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();

    if (!form.nome || !form.dia || !form.horario || !form.cep) {
      alert("Preencha nome, dia, horário e CEP");
      return;
    }

    if (!form.numero) {
      alert("Informe o número do endereço");
      return;
    }

    const normalize = (str) =>
      str
        .replace(/\s+/g, " ")
        .replace(/,\s*,/g, ",")
        .trim();

    const fullAddress = normalize(`
      ${form.endereco},
      ${form.numero},
      ${form.complemento || ""},
      ${form.bairro || ""},
      ${form.cep},
      ${form.cidade},
      ${form.estado},
      Brasil
    `);

    let location =
      await geocodeAddressOptional(fullAddress);

    if (!location) {
      const fallback1 = normalize(`
        ${form.endereco},
        ${form.numero},
        ${form.cidade},
        ${form.estado},
        Brasil
      `);

      location =
        await geocodeAddressOptional(fallback1);
    }

    if (!location) {
      const fallback2 = normalize(`
        ${form.cep},
        ${form.cidade},
        ${form.estado},
        Brasil
      `);

      location =
        await geocodeAddressOptional(fallback2);
    }

    if (!location) {
      console.warn(
        "⚠️ DNA salvo sem localização:",
        fullAddress
      );
    }

    onSubmit({
      ...form,
      location: location ?? null,
    });
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="flex flex-col gap-4"
    >
      <Input
        label="Nome do DNA"
        name="dna_nome"
        value={form.nome}
        onChange={handleChange}
      />

      <Input
        label="Dia da semana"
        name="dna_dia"
        value={form.dia}
        onChange={handleChange}
      />

      <Input
        label="Horário"
        name="dna_horario"
        value={form.horario}
        onChange={handleChange}
      />

      <Input
        label="Nome do líder"
        name="dna_liderNome"
        value={form.liderNome}
        onChange={handleChange}
      />

      <Input
        label="WhatsApp"
        name="dna_whatsapp"
        value={form.whatsapp}
        onChange={handleChange}
      />

      <Input
        label="CEP"
        name="dna_cep"
        value={form.cep}
        onChange={handleChange}
      />

      <Button
        type="button"
        variant="outline"
        onClick={handleBuscarCep}
        disabled={loadingCep}
      >
        {loadingCep
          ? "Buscando CEP..."
          : "Buscar endereço"}
      </Button>

      <Input
        label="Rua / Logradouro"
        name="dna_endereco"
        value={form.endereco}
        onChange={handleChange}
      />

      <Input
        label="Número"
        name="dna_numero"
        value={form.numero}
        onChange={handleChange}
      />

      <Input
        label="Complemento"
        name="dna_complemento"
        value={form.complemento}
        onChange={handleChange}
      />

      <Input
        label="Referência"
        name="dna_referencia"
        value={form.referencia}
        onChange={handleChange}
      />

      <Input
        label="Bairro"
        name="dna_bairro"
        value={form.bairro}
        onChange={handleChange}
      />

      <Input
        label="Cidade"
        name="dna_cidade"
        value={form.cidade}
        onChange={handleChange}
      />

      <Input
        label="Estado"
        name="dna_estado"
        value={form.estado}
        onChange={handleChange}
      />

      <div className="flex gap-3 pt-2">
        <Button type="submit" disabled={isSubmitting}>
          Salvar
        </Button>

        <Button
          type="button"
          variant="ghost"
          onClick={onCancel}
        >
          Voltar
        </Button>
      </div>
    </form>
  );
}

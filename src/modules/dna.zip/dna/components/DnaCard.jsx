import Button from "@/components/ui/Button";

export default function DnaCard({ dna, canEdit, onEdit }) {
  const whatsappLink =
    dna.whatsapp && dna.whatsapp.length >= 10
      ? `https://wa.me/${dna.whatsapp}`
      : null;

  return (
    <div className="rounded-xl border border-base-300 p-4 flex flex-col gap-2">
      <h3 className="text-base font-semibold">
        {dna.nome}
      </h3>

      <p className="text-sm text-base-content/70">
        {dna.dia} • {dna.horario}
      </p>

      {dna.bairro && (
        <p className="text-sm">
          📍 {dna.bairro}
        </p>
      )}

      {typeof dna.distance === "number" && (
        <p className="text-sm font-medium text-primary">
          📏 {dna.distance.toFixed(1)} km de você
        </p>
      )}

      {dna.liderNome && (
        <p className="text-sm">
          👤 Líder: {dna.liderNome}
        </p>
      )}

      <div className="flex gap-2 pt-2">
        {whatsappLink && (
          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1"
          >
            <Button className="w-full">
              Falar no WhatsApp
            </Button>
          </a>
        )}

        {canEdit && (
          <Button variant="ghost" onClick={onEdit}>
            Editar
          </Button>
        )}
      </div>
    </div>
  );
}
